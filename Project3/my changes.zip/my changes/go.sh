#!/bin/sh	

cp arch/i386/boot/bzImage /boot/cop4610-bzImage
mkinitramfs -o /boot/cop4610-initramfs 2.6.36
update-grub
